let bg;
let p1_0, p1_1, p2_0, p2_1;
let paleta1, paleta2;
let p1Activo = false;
let p2Activo = false;

let etapaP1 = 0;
let etapaP2 = 0;
let listoP1 = false;
let listoP2 = false;

function preload() {
  bg = loadImage('background.jpg');
  p1_0 = loadImage('p1_0.png');
  p1_1 = loadImage('p1_1.png');
  p2_0 = loadImage('p2_0.png');
  p2_1 = loadImage('p2_1.png');
  paleta1 = loadImage('paleta1.png');
  paleta2 = loadImage('paleta2.png');
}

function setup() {
  createCanvas(800, 600);
  textFont('Arial');
  textSize(24);  // Fuente más pequeña para los textos
  fill(255);     // Color blanco para los textos
}

function draw() {
  image(bg, 0, 0, width, height);

  let paletaW = width / 3.2;
  let paletaH1 = paleta1.height * (paletaW / paleta1.width);
  let paletaH2 = paleta2.height * (paletaW / paleta2.width);

  let paletaY = height / 4 - paletaH1 / 2;
  let separacion = width / 4;

  let paleta1X = width / 2 - separacion - paletaW / 2;
  let paleta2X = width / 2 + separacion - paletaW / 2;

  image(paleta1, paleta1X, paletaY, paletaW, paletaH1);
  image(paleta2, paleta2X, paletaY, paletaW, paletaH2);

  let p1X = 150;
  let p2X = width - 250;
  let mandoY = height - 170;
  let mandoSize = 150;

  if (listoP1) {
    image(p1_1, p1X, mandoY, mandoSize, mandoSize);
  } else {
    image(p1_0, p1X, mandoY, mandoSize, mandoSize);
  }

  if (listoP2) {
    image(p2_1, p2X, mandoY, mandoSize, mandoSize);
  } else {
    image(p2_0, p2X, mandoY, mandoSize, mandoSize);
  }

  drawEstadoJugador("Jugador 1", width / 4, etapaP1, listoP1, true);
  drawEstadoJugador("Jugador 2", (3 * width) / 4, etapaP2, listoP2, false);

  if (listoP1 && listoP2) {
    fill(0, 255, 0);
    text("¡Ambdós jugadors estan llestos!", width / 2, height - 40);
  }
}

function drawEstadoJugador(nom, x, etapa, listo, esJugador1) {
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(20); // Tamaño más pequeño para "Jugador 1" y "Jugador 2"
  text(nom, x, 40);

  if (listo) {
    fill(0, 255, 0);
    text("Llisto", x, 160);
    return;
  }

  let textos = ["Xutar", "Passar", "Col·locar 1", "Col·locar 2", "Llisto (A/L)"];

  // Posiciones ajustadas para los botones
  let yPos = 160; // Empezar a dibujar el texto desde aquí
  let xOffset = 0;

  // Ajustar las posiciones de los botones para el Jugador 1
  if (esJugador1) {
    if (etapa === 0) {
      yPos = 120;
      xOffset = 40;  // Mover "Xutar" a la derecha
    } else if (etapa === 1) {
      xOffset = -100; // Mover "Passar" a la izquierda
    } else if (etapa === 2) {
      yPos = 200; // "Col·locar 1" más abajo
    } else if (etapa === 3) {
      yPos = 250; // "Col·locar 2" más abajo
      xOffset = 100; // Separar "Col·locar 2"
    }
  }

  // Para el Jugador 2, las posiciones son espejo (a la derecha)
  if (!esJugador1) {
    if (etapa === 1) {
      xOffset = 100; // Mover "Passar" a la derecha para Jugador 2
    } else if (etapa === 2) {
      yPos = 200; // "Col·locar 1" más abajo
    } else if (etapa === 3) {
      yPos = 250; // "Col·locar 2" más abajo
      xOffset = -100; // Separar "Col·locar 2" para Jugador 2
    }
  }

  text(textos[etapa], x + xOffset, yPos);
}

function keyPressed() {
  if (!listoP1) {
    if (etapaP1 === 0 && key === 'j') etapaP1++;
    else if (etapaP1 === 1 && key === 't') etapaP1++;
    else if (etapaP1 === 2 && key === 'a') etapaP1++;
    else if (etapaP1 === 3 && key === 's') etapaP1++;
    else if (etapaP1 === 4 && key === 'a') listoP1 = true;
  }

  if (!listoP2) {
    if (etapaP2 === 0 && key === 'k') etapaP2++;
    else if (etapaP2 === 1 && key === 'g') etapaP2++;
    else if (etapaP2 === 2 && keyCode === LEFT_ARROW) etapaP2++;
    else if (etapaP2 === 3 && keyCode === RIGHT_ARROW) etapaP2++;
    else if (etapaP2 === 4 && key === 'l') listoP2 = true;
  }
}
